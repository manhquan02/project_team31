<?php
return [
    0 => 'Lock',
    1 => 'Active',
];
?>
