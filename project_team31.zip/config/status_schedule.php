<?php
return [
    0=>'Future',
    1=>'Absent',
    2=>'Present'
]
?>
