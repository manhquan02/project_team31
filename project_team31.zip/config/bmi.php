<?php
return [
    1 => 'Gầy độ III',
    2 => 'Gầy độ II',
    3 => 'Gầy độ I',
    4 => 'Bình thường',
    5 => 'Thừa cân',
    6 => 'Béo phì độ I',
    7 => 'Béo phì độ II',
    8 => 'Béo phì độ III',
];
?>
