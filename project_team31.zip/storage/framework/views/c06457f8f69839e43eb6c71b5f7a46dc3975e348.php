<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\datn\project_team31\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>