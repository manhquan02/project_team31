

<?php $__env->startSection('title', 'Thêm phiếu giảm giá'); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-custom">
    <?php echo $__env->make('screens.backend._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card-header">
     <h3 class="card-title">
      Thêm mới Order
     </h3>
    </div>
    <!--begin::Form-->
    <form action="<?php echo e(route('admin.order.postOrder')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
     <div class="card-body">
      
        <div class="form-group row">
            <label class="col-2 col-form-label">Chọn người dùng</label>
            <div class=" col-lg-4 col-md-9 col-sm-12">
             <select name="user_id" class="form-control select2" id="kt_select2_11">
              <option label="Label"></option>
              <optgroup label="Chọn người dùng">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </optgroup>

             </select>
             <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        
        <div class="form-group row">
            <label class="col-2 col-form-label">Chọn gói tập</label>
            <div class="col-lg-4 col-md-9 col-sm-12">
             
                <select name="package_id"  class="form-control select2 is-invalid add_package" id="kt_select2_1_validate" >
                <option value=""><strong>Chọn gói tập</strong></option>
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($package->id); ?>"><?php echo e($package->package_name); ?>  </option>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                   
             </select>
             <?php $__errorArgs = ['package_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>    
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div id="time_package" style="display: none"  class="form-group row">
            <label class="col-2 col-form-label">Chọn ca tập</label>
            <div class=" col-lg-4 col-md-9 col-sm-12">
                <select name="time_id" class="form-control select2 is-invalid" id="kt_select2_2_validate" >

                    <option style="display: none;" value=""></option>
                    <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($time->id); ?>"><?php echo e($time->time_name); ?></option>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                
                </select>
                <?php $__errorArgs = ['time_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>


        <div id="coach_package" style="display: none"  class="form-group row set-coach" >
            <label class="col-2 col-form-label">Chọn huấn viện viên</label>
            <div class=" col-lg-4 col-md-9 col-sm-12">
                <select name="pt_id" class="form-control select2 is-invalid" id="kt_select2_3_validate" >
                    <option style="display: none;" value=""></option>
                    <option >Không có</option>
                    <?php $__currentLoopData = $coachs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($coach->id); ?>"><?php echo e($coach->name); ?></option>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </select> 
                <?php $__errorArgs = ['pt_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-2 col-form-label">Thời gian bắt đầu</label>
                <div class="col-lg-4 col-md-9 col-sm-12">
                    <div class="input-group date" >
                        <input type="date" class="form-control" name="activate_day" placeholder="Select time" id="kt_datetimepicker_7"/>
                        <div class="input-group-append">
                        <span class="input-group-text">
                        <i class="la la-calendar glyphicon-th"></i>
                        </span>
                        </div>
                    </div>
                <span class="form-text text-muted">Thời gian bắt đầu</span>
                <?php $__errorArgs = ['activate_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                 <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div> 
        <div id="weekday_package" style="display: none" class="form-group row">
            <label class="col-2 col-form-label">Chọn thứ tập PT</label>
            <div class=" col-lg-4 col-md-9 col-sm-12">
             <select name="weekday_name[]" class="form-control select2" id="kt_select2_9"  multiple>
              <option label="Label"></option>
              <optgroup label="Chọn 3 ngày">
                <?php $__currentLoopData = $weekdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($weekday->weekday_name); ?>"><?php echo e($weekday->weekday_name); ?></option>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              </optgroup>

             </select>
                <?php $__errorArgs = ['weekday_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           </div>
        
        <div class="form-group row">
            <label  class="col-2 col-form-label">Nhập phiếu giảm giá</label>
            <div style="display: flex" class="col-10">
                <input name="discount_code" style="width: 60%" class="form-control <?php $__errorArgs = ['discount_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="discount_title"  type="text" value="<?php echo e(old('discount_code')); ?>" placeholder="title" id="example-text-input"/>
                <?php $__errorArgs = ['discount_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button style="margin-left: 10px" type="button" class="btn btn-outline-info">Áp dụng</button>
            </div>
            
        </div>
            

      
        
      <div id="method_pm"  class="form-group row">
        <label class="col-2 col-form-label">Chọn phương thức thanh toán</label>
        <div class=" col-lg-4 col-md-9 col-sm-12">
            <select name="payment_method" class="form-control select2" id="kt_select2_10" name="param">


                <option value="1">Thanh toán trực tiếp</option>
                <option value="2">Chuyển khoản ngân hàng</option>

            </select>
                
        </div>
    </div>

    <div  class="form-group row">
        <label class="col-2 col-form-label"><strong>Tổng tiền</strong></label>
        <div class=" col-lg-4 col-md-9 col-sm-12">
            <strong id="total_money" style="color: red">123</strong>
                
        </div>
    </div>
      
     <div class="card-footer">
      <div class="row">
       <div class="col-2">
       </div>
       <div class="col-10">
        <button type="submit" id="btn_disabled" class="btn btn-success mr-2 disabled">Submit</button>
        
       </div>
      </div>
     </div>
    </form>
   </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

$('.add_package').on('change',function(){
    console.log("quân");
      $package_id = $(this).val();
      $.ajax({
          type: 'GET',
          url: "<?php echo e(route('admin.order.setPackage')); ?>",
          data:{
                id: $package_id
            },
          
          success:function(data){
            console.log("abc");
            if(data['result'] == 1){
                console.log(data['package']);
                console.log(data['result']);
                document.querySelector('#coach_package').style.display='flex';
                document.querySelector('#weekday_package').style.display='flex';
                document.querySelector('#time_package').style.display='flex';

                // document.querySelector('#method_pm').classList.add('method_pm_block');
                // document.querySelector('#method_pm').style.display='flex';
                // document.querySelector('#method_pm').style.visibility= 'visible';
                // document.querySelector('#method_pm').style.transform='translate(0)';
                // document.querySelector('#method_pm').style.transition='.5s';
                // document.querySelector('#method_pm').style.opacity='1';
                document.querySelector('#btn_disabled').classList.remove("disabled");
            }
            if(data['result'] == 0){
                document.querySelector('#coach_package').style.display='none';
                document.querySelector('#weekday_package').style.display='none';
                document.querySelector('#time_package').style.display='none';
                document.querySelector('#btn_disabled').classList.remove("disabled");
            }
          }
      });
  });


  $('.add_package').on('change',function(){
    console.log("quân");
      $package_id = $(this).val();
      $.ajax({
          type: 'GET',
          url: "<?php echo e(route('admin.order.setCoach')); ?>",
          data:{
                id: $package_id
            },
          
          success:function(data){
            console.log("abc");
            if(data['result'] == true){
                console.log(data['package']);
                console.log(data['result']);
                document.querySelector(".set-coach").disabled = false;
            }
            else{
                // document.querySelector(".set-coach").innerHTML = `Gói tập này không có PT`;
            }
          }
      });
  })



</script>

<script>
    $(document).ready(function(){
        $('.select2').select2()
    })


    // Class definition
var KTSelect2 = function() {
 // Private functions
    var demos = function() {
    // basic
    $('#kt_select2_1_validate').select2({
    placeholder: "Chọn gói tập"
    });

    // nested
    $('#kt_select2_2_validate').select2({
    placeholder: "Chọn ca tập"
    });

    // multi select
    $('#kt_select2_3_validate').select2({
    placeholder: "Select a state",
    });
    }

    // Public functions
    return {
    init: function() {
    demos();
    }
    };
    }();

    // Initialization
    jQuery(document).ready(function() {
    KTSelect2.init();
    });







</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/order/create.blade.php ENDPATH**/ ?>