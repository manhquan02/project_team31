<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Verification Email</title>
</head>
<body>
<h3><?php echo e(translate('Email confirmation letter')); ?></h3>
<a href="<?php echo e(route('verification', [$data['code'], $data['request']])); ?>"><?php echo e(translate('Click here to sign up for an account')); ?></a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/email/verify.blade.php ENDPATH**/ ?>
