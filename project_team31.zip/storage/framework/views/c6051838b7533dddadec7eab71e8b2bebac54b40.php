<!--begin::Header-->
<div id="kt_header" class="header header-fixed">
    <!--begin::Container-->
    <div class="container-fluid d-flex align-items-stretch justify-content-between">
        <!--begin::Header Menu Wrapper-->
        <div class="header-menu-wrapper header-menu-wrapper-left" id="kt_header_menu_wrapper">
        </div>
        <!--end::Header Menu Wrapper-->
        <?php
            $language = \App\Models\Language::where('status', 1)->first();
            $language_other = \App\Models\Language::where('status', 0)->get();
        ?>
            <!--begin::Topbar-->
        <div class="topbar">
            <!--begin::User-->
            <div class="dropdown">
                <!--begin::Toggle-->
                <div class="topbar-item" data-toggle="dropdown" data-offset="10px,0px">
                    <div class="btn btn-icon btn-clean btn-dropdown btn-lg mr-1">
                        <?php if($language != null): ?>
                            <img class="h-20px w-20px rounded-sm"
                                 src="<?php echo e(asset($language->flag)); ?>" alt=""/>
                        <?php else: ?>
                            <img class="h-20px w-20px rounded-sm"
                                 src="<?php echo e(asset(env('DEFAULT_FLAG'))); ?>" alt=""/>
                        <?php endif; ?>
                    </div>
                </div>
                <!--end::Toggle-->
                <!--begin::Dropdown-->
                <?php if(count($language_other) > 0): ?>
                <div class="dropdown-menu p-0 m-0 dropdown-menu-anim-up dropdown-menu-sm dropdown-menu-right">
                    <!--begin::Nav-->
                    <ul class="navi navi-hover py-4">
                        <!--begin::Item-->
                        <?php $__currentLoopData = $language_other; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="navi-item">
                            <a href="<?php echo e(route('admin.index', ['language'=> $lang->code])); ?>" class="navi-link">
													<span class="symbol symbol-20 mr-3">
														<img
                                                            src="<?php echo e(asset($lang->flag)); ?>"
                                                            alt=""/>
													</span>
                                <span class="navi-text"><?php echo e($lang->name); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!--end::Item-->
                    </ul>
                    <!--end::Nav-->
                </div>
                <?php endif; ?>
                <!--end::Dropdown-->
            </div>
            <div class="topbar-item">
                <div class="btn btn-icon btn-icon-mobile w-auto btn-clean d-flex align-items-center btn-lg px-2"
                     id="kt_quick_user_toggle">
                    <span class="text-muted font-weight-bold font-size-base d-none d-md-inline mr-1">Hi,</span>
                    <span class="text-dark-50 font-weight-bolder font-size-base d-none d-md-inline mr-3">Admin</span>
                    <span class="symbol symbol-lg-35 symbol-25 symbol-light-success">
                        <span class="symbol-label font-size-h5 font-weight-bold">S</span>
                    </span>
                </div>
            </div>
            <!--end::User-->
        </div>
        <!--end::Topbar-->
    </div>
    <!--end::Container-->
</div>
<!--end::Header-->
<?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/layouts/backend/header.blade.php ENDPATH**/ ?>