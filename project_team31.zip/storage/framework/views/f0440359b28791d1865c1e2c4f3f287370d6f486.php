<?php $__env->startSection('title', translate('Language Management')); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <div class="card card-custom">
            <div class="card-header border-0 pt-6 pb-0">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(translate('Configuration')); ?>

                        <span
                            class="d-block text-muted pt-2 font-size-sm"><?php echo e(translate('Language')); ?></span>
                    </h3>
                </div>
                <div class="card-title">
                    <form action="">
                        <div class="input-icon" style="margin-right: 280px">
                            <input type="text" class="form-control" style="width: 200%"
                                   name="keyword" <?php if(request('keyword')): ?> value="<?php echo e(request('keyword')); ?>" <?php endif; ?>
                                   placeholder="<?php echo e(translate('Type keywords and Enter ...')); ?>"/>
                        </div>
                        <button hidden>Search</button>
                    </form>
                </div>
            </div>
            <form action="<?php echo e(route('admin.language.store_translate', $lang)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <!--begin: Datatable-->
                    <table class="table table-separate table-head-custom table-checkable" id="kt_datatable">
                        <thead>
                        <tr>
                            <th>#ID</th>
                            <th><?php echo e(translate('KeyWord')); ?></th>
                            <th><?php echo e(translate('Value')); ?></th>
                            <th><?php echo e(translate('Actions')); ?></th>
                        </tr>
                        </thead>
                        <tbody id="tbody">
                        <?php if($translations != null): ?>
                            <?php $__currentLoopData = $translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->lang_in); ?></td>
                                    <td><input type="text" name="lang_value[<?php echo e($item->id); ?>]" class="form-control"
                                               value="<?php echo e($item->lang_value); ?>"></td>
                                    <td><a class="btn-confirm" data-title="<?php echo e(translate('Are you sure you want to delete ?')); ?>" data-url="<?php echo e(route('admin.language.delete_translation', $item->id)); ?>"
                                           style="margin-left: 12px; cursor: pointer"><i class="flaticon2-trash text-danger"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                    <div>
                        <?php echo e($translations->appends(request()->input())->links()); ?>

                    </div>

                    <!--end: Datatable-->
                    <?php if(count($translations) > 0): ?>
                        <button type="submit" class="btn btn-success mr-2"><?php echo e(translate('Save')); ?></button>
                    <?php else: ?>
                        <div class="card-body">
                            <div class="mb-7">
                                <div class="row align-items-center">
                                    <h2 style="color: #999999; text-align: center"><?php echo e(translate('No records found')); ?></h2>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/configuration/language/translation.blade.php ENDPATH**/ ?>