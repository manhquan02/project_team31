<?php
return [
    0 => 'No response yet',
    1 => 'Responded'
];
?>
