<?php
return [
    0 => 'Hidden',
    1 => 'Show',
];
?>
