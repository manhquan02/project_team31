<?php $__env->startSection('title', translate('Package Management')); ?>
<?php $__env->startSection('content'); ?>
<div>
    <div class="card card-custom">

        <div class="card-header flex-wrap border-0 pt-6 pb-0">
            <div class="card-title">
                <h3 class="card-label"><?php echo e(translate('Package management')); ?>

                    <span class="d-block text-muted pt-2 font-size-sm"><?php echo e(translate('Add new')); ?></span>
                </h3>
            </div>
            <div class="card-toolbar">
                <!--begin::Button-->
                <a href="<?php echo e(route('admin.package.index')); ?>" class="btn btn-primary font-weight-bolder">
                    <span class="svg-icon svg-icon-md">
                        <!--begin::Svg Icon | path:assets/media/svg/icons/Design/Flatten.svg-->
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <rect x="0" y="0" width="24" height="24" />
                                <circle fill="#000000" cx="9" cy="15" r="6" />
                                <path d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z" fill="#000000" opacity="0.3" />
                            </g>
                        </svg>
                        <!--end::Svg Icon-->
                    </span><?php echo e(translate('List Packages')); ?></a>
                <!--end::Button-->
            </div>
        </div>
        <form action="<?php echo e(route('admin.package.update', $package->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="card-body">
                <div class="form-group row">
                    <label class="col-2 col-form-label"><?php echo e(translate('Package Name')); ?> <span class="text-danger">*</span></label>
                    <div class="col-10">
                        <input class="form-control" name="package_name" type="text" value="<?php echo e(old('package_name') ? old('package_name') : $package->package_name); ?>" />
                        <?php $__errorArgs = ['package_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-2 col-form-label"><?php echo e(translate('Subject')); ?> <span class="text-danger">*</span></label>
                    <div class="col-10">
                        <select name="subject_id" class="form-control select2">
                            <option selected value="<?php echo e($package->subject_id); ?>"><?php echo e($package->subject->subject_name); ?></option>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if(old('subject_id')==$item->id): ?> selected <?php endif; ?>><?php echo e($item->subject_name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-tel-input" class="col-2 col-form-label"><?php echo e(translate('Avatar')); ?> </label>
                    <div class="col-10">
                        <input type="file" class="form-control" name="avatar" value="<?php echo e(old('avatar')); ?>" />
                        <img id="image" src="<?php echo e(asset($package->avatar)); ?>" width="60px" height="60px">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-2 col-form-label"><?php echo e(translate('Price')); ?> <span class="text-danger">*</span></label>
                    <div class="col-10">
                        <input class="form-control" name="price" type="text" value="<?php echo e(old('price') ? old('price') : $package->price); ?>" />
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-2 col-form-label"><?php echo e(translate('% Discount')); ?></label>
                    <div class="col-10">
                        <input class="form-control" name="price_sale" type="text" value="<?php echo e(old('price_sale') ? old('price_sale') : $package->price_sale); ?>" />
                        <?php $__errorArgs = ['price_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-tel-input" class="col-2 col-form-label"><?php echo e(translate('Type Package')); ?> <span class="text-danger">*</span></label>
                    <div class="col-10">
                        <select class="form-control" name="type_package">
                            <option selected value="<?php echo e($package->type_package); ?>"><?php echo e(typePackage()[$package->type_package]); ?></option>
                            <?php $__currentLoopData = typePackage(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($key != $package->type_package): ?>
                            <option <?php if(old('$type_package')==$key): ?> selected <?php endif; ?> value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['type_package'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-password-input" class="col-2 col-form-label"><?php echo e(translate('Short Description')); ?> <span class="text-danger">*</span></label>
                    <div class="col-10">
                        <input type="text" class="form-control" name="short_description" value="<?php echo e(old('short_description') ? old('short_description') : $package->short_description); ?>">
                        <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="example-password-input" class="col-2 col-form-label"><?php echo e(translate('Description')); ?>

                        <span class="text-danger">*</span></label>
                    <div class="col-10">
                        <textarea id="summernote" class="form-control" name="description"><?php echo old('description') ? old('description') : $package->description; ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="example-password-input" class="col-2 col-form-label"><?php echo e(translate('Have a Coach ?')); ?> </label>
                    <div class="col-10 p-3">
                        <input type="checkbox" id="pt" name="set_pt" <?php if($package->set_pt == 1): ?> checked <?php endif; ?>>
                        <?php $__errorArgs = ['set_pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <!-- <div id="weekday_pt" class="form-group row">

                </div> -->
                <div class="form-group row">
                    <label for="example-password-input" class="col-2 col-form-label"></label>
                    <div class="col-10">
                        <button type="submit" class="btn btn-success mr-2"><?php echo e(translate('Save')); ?></button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2()
    });

    /* console.log($('#pt').prop('checked'));
    if ($('#pt').prop('checked') == true) {
        content = ` <label for="example-password-input" class="col-2 col-form-label"><?php echo e(translate('Number of pt on week')); ?> <span class="text-danger">*</span></label>
                        <div class="col-10 p-3">
                            <input class="form-control" type="number" name="weekday_pt" value="<?php echo e(old('weekday_pt') ? old('weekday_pt') : $package->weekday_pt); ?>">
                            <?php $__errorArgs = ['weekday_pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>`

        $('#weekday_pt').html(content);
    }

    $(document).on('click', '#pt', function() {
        console.log($(this).prop('checked'));
        let content = ``;
        if ($(this).prop('checked') == true) {
            content = ` <label for="example-password-input" class="col-2 col-form-label"><?php echo e(translate('Number of pt on week')); ?> <span class="text-danger">*</span></label>
                        <div class="col-10 p-3">
                            <input class="form-control" type="number" name="weekday_pt" value="<?php echo e(old('weekday_pt') ? old('weekday_pt') : $package->weekday_pt); ?>">
                            <?php $__errorArgs = ['weekday_pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>`
        }

        $('#weekday_pt').html(content);
    }) */
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/package/edit.blade.php ENDPATH**/ ?>