<section class="about-area-2 bg-black pt-130 pb-130">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-10">
                <div class="about-thumb-wrap text-center mb-30">
                    <div class="about-img-2 mb-70">
                        <img src="frontend/assets/img/thumb/thumb-4.jpg" alt="about">
                    </div>
                    <a href="about.html" class="btn btn-gra">
                       Xem Ngay <i class="fas fa-angle-double-right"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="about-content-2 pt-35">
                    <div class="section-title-3 text-white">
                        <h3 class="bars">Chúng Tôi Luôn Cố Gắng Để Mang Lại Trải Nghiệm Tốt Nhất</h3>
                    </div>
                    <div class="about-text mb-45">
                    </div>
                    <div class="about-video-play">
                        <img src="frontend/assets/img/thumb/thumb-5.jpg" alt="thumb">
                        <a href="https://www.youtube.com/watch?v=ZIKt1-r3PL0" class="popup-video read-more">
                            <img src="frontend/assets/img/icon/play.png" alt="icon">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="about-shape">
        <img class="rotateme" src="frontend/assets/img/shape/shape-5.png" alt="shape">
    </div>
</section><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/layouts/frontend/about-area.blade.php ENDPATH**/ ?>