

<?php $__env->startSection('title', 'Trang người dùng'); ?>

<?php $__env->startSection('content'); ?>
<div>

    <div class="card card-custom">
        <div class="card-header flex-wrap border-0 pt-6 pb-0">
            <div class="card-title">
                <h3 class="card-label">Remote Datasource
                <span class="d-block text-muted pt-2 font-size-sm">Sorting &amp; pagination remote datasource</span></h3>
            </div>
            <div class="card-toolbar">
                <!--begin::Dropdown-->
                <div  class="dropdown dropdown-inline mr-2">
                    <button type="button" class="btn btn-light-primary font-weight-bolder dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="svg-icon svg-icon-md">
                        <!--begin::Svg Icon | path:assets/media/svg/icons/Design/PenAndRuller.svg-->
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <rect x="0" y="0" width="24" height="24" />
                                <path d="M3,16 L5,16 C5.55228475,16 6,15.5522847 6,15 C6,14.4477153 5.55228475,14 5,14 L3,14 L3,12 L5,12 C5.55228475,12 6,11.5522847 6,11 C6,10.4477153 5.55228475,10 5,10 L3,10 L3,8 L5,8 C5.55228475,8 6,7.55228475 6,7 C6,6.44771525 5.55228475,6 5,6 L3,6 L3,4 C3,3.44771525 3.44771525,3 4,3 L10,3 C10.5522847,3 11,3.44771525 11,4 L11,19 C11,19.5522847 10.5522847,20 10,20 L4,20 C3.44771525,20 3,19.5522847 3,19 L3,16 Z" fill="#000000" opacity="0.3" />
                                <path d="M16,3 L19,3 C20.1045695,3 21,3.8954305 21,5 L21,15.2485298 C21,15.7329761 20.8241635,16.200956 20.5051534,16.565539 L17.8762883,19.5699562 C17.6944473,19.7777745 17.378566,19.7988332 17.1707477,19.6169922 C17.1540423,19.602375 17.1383289,19.5866616 17.1237117,19.5699562 L14.4948466,16.565539 C14.1758365,16.200956 14,15.7329761 14,15.2485298 L14,5 C14,3.8954305 14.8954305,3 16,3 Z" fill="#000000" />
                            </g>
                        </svg>
                        <!--end::Svg Icon-->
                    </span>Export</button>
                    <!--begin::Dropdown Menu-->
                    <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right">
                        <!--begin::Navigation-->
                        <ul class="navi flex-column navi-hover py-2">
                            <li class="navi-header font-weight-bolder text-uppercase font-size-sm text-primary pb-2">Choose an option:</li>
                            <li class="navi-item">
                                <a href="#" class="navi-link">
                                    <span class="navi-icon">
                                        <i class="la la-print"></i>
                                    </span>
                                    <span class="navi-text">Print</span>
                                </a>
                            </li>
                            <li class="navi-item">
                                <a href="#" class="navi-link">
                                    <span class="navi-icon">
                                        <i class="la la-copy"></i>
                                    </span>
                                    <span class="navi-text">Copy</span>
                                </a>
                            </li>
                            <li class="navi-item">
                                <div wire:click="exportUser()" class="navi-link">
                                    <span class="navi-icon">
                                        <i class="la la-file-excel-o"></i>
                                    </span>
                                    <span class="navi-text">Excel</span>
                                </div>
                            </li>
                            <li class="navi-item">
                                <a href="#" class="navi-link">
                                    <span class="navi-icon">
                                        <i class="la la-file-text-o"></i>
                                    </span>
                                    <span class="navi-text">CSV</span>
                                </a>
                            </li>
                            <li class="navi-item">
                                <a href="#" class="navi-link">
                                    <span class="navi-icon">
                                        <i class="la la-file-pdf-o"></i>
                                    </span>
                                    <span class="navi-text">PDF</span>
                                </a>
                            </li>
                        </ul>
                        <!--end::Navigation-->
                    </div>
                    <!--end::Dropdown Menu-->
                </div>
                <!--end::Dropdown-->
                <!--begin::Button-->
                <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-primary font-weight-bolder">
                <span class="svg-icon svg-icon-md">
                    <!--begin::Svg Icon | path:assets/media/svg/icons/Design/Flatten.svg-->
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <rect x="0" y="0" width="24" height="24" />
                            <circle fill="#000000" cx="9" cy="15" r="6" />
                            <path d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z" fill="#000000" opacity="0.3" />
                        </g>
                    </svg>
                    <!--end::Svg Icon-->
                </span>Thêm hội viên</a>
                <!--end::Button-->
            </div>
        </div>
        <div class="card-body">
            
            <!--begin: Search Form-->
            <form action="">
            <!--begin::Search Form-->
            <div class="mb-7">
                <div class="row align-items-center">
                    <div class="col-lg-9 col-xl-8">
                        <div class="row align-items-center">
                            <div class="col-md-4 my-2 my-md-0">
                                <div class="input-icon">
                                    <input type="text" name="q" id="txtSearch" value="<?php echo e(request('q')); ?>" class="form-control" value="<?php echo e(request()->query('q') ?: ''); ?>" placeholder="Nhập tên..."  />
                                    <span>
                                        <i class="flaticon2-search-1 text-muted"></i>
                                </div>
                            </div>
                            <div class="col-md-4 my-2 my-md-0">
                                <div class="d-flex align-items-center">
                                    <label class="mr-3 mb-0 d-none d-md-block">OrderBy:</label>
                                    <select name="sort" class="form-control" id="kt_datatable_search_status">
                                        <option <?php if(request('sort', -1) == 'idAsc'): ?> selected <?php endif; ?> value="idAsc">ID ASC</option>
                                        <option <?php if(request('sort', -1) == 'idDesc'): ?> selected <?php endif; ?> value="idDesc">ID DESC</option>        
                                        

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4 my-2 my-md-0">
                                <div class="d-flex align-items-center">
                                    <label class="mr-3 mb-0 d-none d-md-block">Status:</label>
                                    <select name="status" class="form-control" id="kt_datatable_search_type">
                                        <option value="">All</option>
                                        <option <?php if(request('status', -1) == '1'): ?> selected <?php endif; ?> value="1">On</option>
                                        <option <?php if(request('status', -1) == '0'): ?> selected <?php endif; ?> value="0">Off</option>
                                        
    
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-xl-4 mt-5 mt-lg-0">
                        
                        <button class="btn btn-light-primary px-6 font-weight-bold">Lọc</button>
                    </div>
                </div>
            </div>
            </form>
            <!--end::Search Form-->
            <!--end: Search Form-->
            <!--begin: Datatable-->
            <div class="datatable datatable-bordered datatable-head-custom" id="kt_datatable"></div>
            <!--end: Datatable-->
        </div>
        <div class="card-body">
            <!--begin: Datatable-->
            <table class="table table-separate table-head-custom table-checkable" id="kt_datatable">
                <thead>
                    <tr>
                        <th>Record ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Avatar</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                        <th>Edit Role</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    
                     <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <img src="<?php echo e($user->Avatar); ?>" width="200px" alt="">
                        </td>
                        <td  class="show_role<?php echo e($user->id); ?>">
                            <?php echo e(1); ?>

                        </td>
                        <td>
                            <?php if($user->status == 1): ?>
                            <span
                                class="label label-inline label-light-primary font-weight-bold">Hiện</span>
                        <?php else: ?>
                            <span class="label label-inline label-light-danger font-weight-bold">Khoá</span>
                        <?php endif; ?>
                        </td>
                        <td nowrap="nowrap">
                            <a class="btn btn-light  btn-sm mr-2"
                                id="change_status" >
                                <i class="ki ki-reload text-warning"></i>
                            </a>
                        </td>
                            <td>
                            <button  
                            onclick="javascript:name_edit_role(<?php echo e($user); ?>)"             
                                class="btn btn-light-primary px-6 font-weight-bold"
    
                                data-bs-toggle="modal" data-bs-target="#exampleModal"
                                >
                                <i class="flaticon2-gear text-primary"></i>
                            </button>
                            
                        </td>
                    </tr>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
                </tbody>
            </table>
            <!--end: Datatable-->
            
        </div>
    </div>
    
    </div>

    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Cấp quyền người dùng</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form id="update_user_role">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label">Name</label>
                  <input type="email" disabled class="form-control name_edit_role" id="exampleInputEmail1" aria-describedby="emailHelp">
                  <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                </div>
                <select id="name_role" class="form-select form-select-lg mb-3" aria-label="Default select example">
                    <option name="role"  selected>Phân quyền</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                <div class="mb-3 form-check">
                  <input type="text" hidden id="update_role" name="id" id="">
                </div>
                <button type="button" data-id="" data-token="<?php echo e(csrf_token()); ?>"     onclick="update_user_role('exampleModal','update_user_role')" class="btn btn-primary">Submit</button>
              </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

    function name_edit_role(item) {
        console.log(item.name);
        document.querySelector('.name_edit_role').value = item.name;
        document.getElementById('update_role').value = item.id;
        var id = document.getElementById('id');
            
    }

    function update_user_role(id_modal,id_form) {
        console.log(id_modal);
        
        // formData = new FormData(document.getElementById(id_form));
        // console.log(formData)
        var token = $(this).data("token");
        $.ajax({
            type: 'post',
            url: "<?php echo e(route('admin.user.editRole')); ?>",
            data: {
                "_method": 'POST',
                "_token": token,
                "id": document.getElementById('update_role').value,
                "role": document.getElementById('name_role').value
            },
            // processData: false,
            // contentType: false,
            success: function(data) {
                console.log(document.getElementById('update_role').value);
                console.log( document.getElementById('name_role').value);
                id = document.getElementById('update_role').value;
                console.log(data['user']);
                $('.show_role'+id).html(`["${data['role']}"]`);
                Swal.fire(
                    'Good job!',
                    'Thanh cong',
                    'success'
                )
                modal = document.querySelector('.modal-backdrop')
                modal.classList.remove('show');
                modal.style.display = 'none'
                modal1 = document.getElementById(id_modal)
                modal1.classList.remove('show');
                modal1.style.display = 'none'
                // window.location.reload()
            },
            error: function(response) {
                // console.log(response.responseJSON.errors.name)
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    // text: response.responseJSON.errors.name[0],
                    footer: '<a href="">Quay trở lại?</a>'
                })
            }
        });
        $.ajaxSetup({
            headers: {
                'csrftoken': '<?php echo e(csrf_token()); ?>'
            }
        });
    }


      $('#change_status').on('click',function(){
    console.log("quân");
      $package_id = $(this).val();
      $.ajax({
          type: 'GET',
          url: "<?php echo e(route('admin.user.editStatus')); ?>",
          data:{
                id: $package_id
            },
          
          success:function(data){
            console.log("abc");
            if(data['result'] == true){
                console.log(data['package']);
                console.log(data['result']);
                document.querySelector(".set-coach").disabled = false;
                // document.querySelector('#total_money').innerHTML = `${data['total_money']}`;
            }
            else{
                // document.querySelector(".set-coach").innerHTML = `Gói tập này không có PT`;
            }
          }
      });
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/user/list-user.blade.php ENDPATH**/ ?>