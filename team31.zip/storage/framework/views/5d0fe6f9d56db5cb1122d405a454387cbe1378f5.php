<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Well done: </strong> <?php echo session('success'); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('failed')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <strong>Warning: </strong> <?php echo session('failed'); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if($errors->all()): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <strong>Warning: </strong> Please check the form carefully for errors!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if(session('msg')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <strong>Error: </strong> <?php echo e(session('msg')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/_alert.blade.php ENDPATH**/ ?>