<?php $__env->startSection('title', translate('Shift management')); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <div class="card card-custom">
            <div class="card-header flex-wrap border-0 pt-6 pb-0">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(translate('Shift management')); ?>

                        <span class="d-block text-muted pt-2 font-size-sm"><?php echo e(translate('List')); ?></span></h3>
                </div>
                <div class="card-toolbar">
                    <!--begin::Button-->
                    <a href="<?php echo e(route('admin.time.create')); ?>" class="btn btn-primary font-weight-bolder">
                <span class="svg-icon svg-icon-md">
                    <!--begin::Svg Icon | path:assets/media/svg/icons/Design/Flatten.svg-->
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                         height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <rect x="0" y="0" width="24" height="24"/>
                            <circle fill="#000000" cx="9" cy="15" r="6"/>
                            <path
                                d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z"
                                fill="#000000" opacity="0.3"/>
                        </g>
                    </svg>
                    <!--end::Svg Icon-->
                </span><?php echo e(translate('Add new shift')); ?></a>
                    <!--end::Button-->
                </div>
            </div>
            <div class="card-body">
                <!--begin: Datatable-->
                <table class="table table-separate table-head-custom table-checkable" id="kt_datatable">
                    <thead>
                    <tr>
                        <th>#ID</th>
                        <th><?php echo e(translate('Shift name')); ?></th>
                        <th><?php echo e(translate('Start time')); ?></th>
                        <th><?php echo e(translate('End time')); ?></th>
                        <th><?php echo e(translate('Actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody id="tbody">
                    <?php if($times != null): ?>
                        <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->time_name); ?></td>
                                <td><?php echo e($item->start_time); ?></td>
                                <td><?php echo e($item->end_time); ?></td>
                                <td>
                                <a title="<?php echo e(translate('View')); ?>"
                                       href="<?php echo e(route('admin.time.edit', $item->id)); ?>"><i
                                            class="flaticon-eye text-info"></i></a>
                                    <a title="<?php echo e(translate('Delete')); ?>" class="btn-confirm" data-title="Are you sure you want to delete ?" data-url="<?php echo e(route('admin.time.delete', $item->id)); ?>"
                                       style="margin-left: 12px; cursor: pointer"><i class="flaticon2-trash text-danger"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <!--end: Datatable-->
                <div>
                    <?php echo e($times->appends(request()->input())->links()); ?>

                </div>
                <?php if(count($times) <= 0): ?>
                    <div class="card-body">
                        <!--begin::Search Form-->
                        <div class="mb-7">
                            <div class="row align-items-center">
                                <h2 style="color: #999999; text-align: center"><?php echo e(translate('No records found')); ?></h2>
                            </div>
                        </div>
                        <!--end::Search Form-->
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/time/index.blade.php ENDPATH**/ ?>