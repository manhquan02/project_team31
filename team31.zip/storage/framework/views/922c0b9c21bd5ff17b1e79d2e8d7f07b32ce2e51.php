<?php $__env->startSection('title', translate('Package Management')); ?>
<?php $__env->startSection('content'); ?>

    <div>
        <div class="card card-custom">
            <div class="card-header flex-wrap border-0 pt-6 pb-0">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(translate('Package Management')); ?>

                        <span class="d-block text-muted pt-2 font-size-sm"><?php echo e(translate('List')); ?></span></h3>
                </div>
                <div class="card-toolbar">
                    <!--begin::Button-->
                    <a href="<?php echo e(route('admin.package.create')); ?>" class="btn btn-primary font-weight-bolder">
                <span class="svg-icon svg-icon-md">
                    <!--begin::Svg Icon | path:assets/media/svg/icons/Design/Flatten.svg-->
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px"
                         height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                            <rect x="0" y="0" width="24" height="24"/>
                            <circle fill="#000000" cx="9" cy="15" r="6"/>
                            <path
                                d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z"
                                fill="#000000" opacity="0.3"/>
                        </g>
                    </svg>
                    <!--end::Svg Icon-->
                </span><?php echo e(translate('Add New Package')); ?></a>
                    <!--end::Button-->
                </div>
            </div>
            <div class="card-body">
                <!--begin::Search Form-->
                <form action="">
                    <div class="mb-7">
                        <div class="row align-items-center">
                            <div class="col-lg-9 col-xl-8">
                                <div class="row align-items-center">
                                    <div class="col-md-6 my-2 my-md-0">
                                                <select name="subject_id"  class="form-control select2 is-invalid" id="kt_select2_1_validate" >
                                                    <option selected disabled><?php echo e(translate('Choose a subject')); ?></option>
                                                    <?php
                                                    $subjects = \App\Models\Subject::all();
                                                    ?>
                                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option  value="<?php echo e($item->id); ?>" <?php if(request('subject_id', -1) == $item->id): ?> selected <?php endif; ?>><?php echo e($item->subject_name); ?>  </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                    </div>
                                    <div class="col-md-6 my-2 my-md-0">
                                        <div class="d-flex align-items-center">
                                            <select class="form-control" name="status">
                                                <option selected disabled><?php echo e(translate('Choose a status')); ?></option>
                                                <option value="0" <?php if(request('status', -1) == 0): ?> selected <?php endif; ?>><?php echo e(translate('Lock')); ?></option>
                                                <option value="1" <?php if(request('status', -1) == 1): ?> selected <?php endif; ?>><?php echo e(translate('Active')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-xl-4 mt-5 mt-lg-0">
                                <button
                                    class="btn btn-light-primary px-6 font-weight-bold"><?php echo e(translate('Search')); ?></button>
                            </div>
                        </div>
                    </div>
                    <!--end::Search Form-->
                </form>
                <!--end::Search Form-->
            </div>
            <div class="card-body">
                <!--begin: Datatable-->
                <table class="table table-separate table-head-custom table-checkable" id="kt_datatable">
                    <thead>
                    <tr>
                        <th>#ID</th>
                        <th><?php echo e(translate('Package Name')); ?></th>
                        <th><?php echo e(translate('Subject Name')); ?></th>
                        <th><?php echo e(translate('Avatar')); ?></th>
                        <th><?php echo e(translate('Listed Price')); ?></th>
                        <th><?php echo e(translate('Promotion price')); ?></th>
                        <th><?php echo e(translate('Type package')); ?></th>
                        <th><?php echo e(translate('Status')); ?></th>
                        <th><?php echo e(translate('Actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody id="tbody">
                    <?php if($packages != null): ?>
                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->package_name); ?></td>
                                <td><?php echo e($item->subject->subject_name); ?></td>
                                <td>
                                    <img width="100px" height="100px" src="<?php echo e(asset($item->avatar)); ?>" alt="">
                                </td>
                                <td><?php echo e(number_format($item->price,0,'.','.')); ?></td>
                                <td><?php echo e(number_format($item->into_price,0,'.','.')); ?></td>
                                <td><?php echo e(typePackage()[$item->type_package]); ?></td>
                                <td><span
                                        class="label label-inline <?php echo e($item->status == 1 ? 'label-light-primary': 'label-light-danger'); ?> font-weight-bold"><?php echo e(translate(config('status_package.'.$item->status) )); ?></span>
                                </td>
                                <td>
                                    <a title="<?php echo e(translate('View')); ?>"
                                       href="<?php echo e(route('admin.package.edit', $item->id)); ?>"><i
                                            class="flaticon-eye text-info"></i></a>
                                    <a title="<?php echo e(translate('Change Status')); ?>" class="btn-confirm"
                                       data-title="Are you sure you want to change the status ?"
                                       data-url="<?php echo e(route('admin.package.change_status', $item->id)); ?>"
                                       style="margin-left: 12px; cursor: pointer"><i
                                            class="flaticon-warning text-warning"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <div>
                    <?php echo e($packages->appends(request()->input())->links()); ?>

                </div>
                <!--end: Datatable-->
                <?php if(count($packages) <= 0): ?>
                    <div class="card-body">
                        <div class="mb-7">
                            <div class="row align-items-center">
                                <h2 style="color: #999999; text-align: center"><?php echo e(translate('No records found')); ?></h2>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $('.select2').select2()
        });
    </script>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\datn\project_team31\resources\views/screens/backend/package/index.blade.php ENDPATH**/ ?>